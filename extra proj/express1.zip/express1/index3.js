var express = require("express")
var app = express()
var router = require('./loginroutes');
app.use("/account", router);
var server = app.listen(8081, function(){
    console.log("Server started ");
});