var express = require("express")
var bodyParser = require("body-parser")
var db = require("./db")
var app = express()
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))
app.set("view engine", "pug")
app.set("views", "database/views")
app.get("/", function(req,res){
    res.render("myform");
})
app.post("/", function(req,res){
    console.log("Body::", req.body)
    if(!req.body.uname || !req.body.age){
        res.render("show_msg", {type:"error", msg:"Info Missing!"});
    } else {
        var u1 = {
            uname:req.body.uname,
            age: req.body.age
        }
        db.insert(u1)
        res.render("show_msg", {type:"success", msg:"Done!"});
    }
})

var server = app.listen(8081);