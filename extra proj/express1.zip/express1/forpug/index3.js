var express = require("express")
var app = express()
app.use(express.static("forpug/images"))
app.set("view engine", "pug")
app.set("views", "forpug/views")
app.get("/", function(req,res){
    res.render("showimg");
})
var server = app.listen(8081);