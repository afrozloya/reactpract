var express = require("express")
var bodyParser = require("body-parser")
var app = express()
app.use(express.static("forpug/images"))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))
app.set("view engine", "pug")
app.set("views", "forpug/views")
app.get("/", function(req,res){
    res.render("myform");
})
app.post("/", function(req,res){
    console.log("Body::", req.body)
    res.render("show_msg", {msg:"Done!"});
})

var server = app.listen(8081);