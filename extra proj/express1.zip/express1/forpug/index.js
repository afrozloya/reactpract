var express = require("express")
var app = express()
app.set("view engine", "pug")
app.set("views", "forpug/views")
app.get("/about", function(req,res){
    res.render("hello", {title: "About US", msg:"Bla bla bla"});
})
app.route("/contact").get(function(req,res){
    res.render("hello", {title: "Contact", msg:"9998889998"});
})
var server = app.listen(8081);