var express = require("express")
var app = express()
app.set("view engine", "pug")
app.set("views", "forpug/views")
app.get("/a", function(req,res){
    res.render("home", {uinfo: {name:"kake"}});
})
app.get("/b", function(req,res){
    res.render("home");
})
app.get("/c", function(req,res){
    res.render("home2", users=["ajay", "akash", "sid"]);
})
app.get("/d", function(req,res){
    res.render("home3");
})

var server = app.listen(8081);