var  MongoClient =  require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb3/";
MongoClient.connect(url, function(err, db){
    if(err) throw err;
    var dbo = db.db("mydb3");
    var query = {name: /a/i}
    var sortby = {name:-1}
    dbo.collection("customers").find(query, { projection: { _id: 0, name: 1, address: 1 }}).sort(sortby).toArray(function(err, res){
        if(err) throw err;
        console.log(res);
    })

    console.log("bla bla!!");
})
