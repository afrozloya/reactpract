import * as actTypes from '../actions/actionTypes'


const initValues = {
    todos: null,
    loading: false,
    error: null,
    selectedTodo: null
}

const fetchTodos = (state  , action) => {

}

const todoReducers = (state = initValues , action) => {
    switch (action.type) {
        case actTypes.FETCH_TODOS:
            return fetchTodos(state, action)
        default:
            return state
    }
}

export default todoReducers;    