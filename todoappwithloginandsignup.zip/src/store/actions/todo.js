import * as actTypes from './actionTypes'
import axios from '../../axios'

export const fetchTodos = (userid, token) => {
    return (dispatch) => {
        dispatch(fetchTodosStart());
        let url = "todos.json";
        axios.get(url)
        .then(resp => {
            let mytodos = []
            Object.keys(resp.data).forEach(e => {
                mytodos.push({
                    id: e,
                    ...resp.data[e]
                })
            })
            dispatch(fetchTodosSuccess(mytodos));
        })
        .catch(err => {
            dispatch(fetchTodosFail(err));
        })
        
    }
}

export const fetchTodosStart = () => {
    return {
        type: actTypes.FETCH_TODOS_START,
    }
}

export const fetchTodosSuccess = (todos) => {
    return {
        type: actTypes.FETCH_TODOS_SUCCESS,
        todos: todos
    }
}

export const fetchTodosFail = (error) => {
    return {
        type: actTypes.FETCH_TODOS_FAIL,
        error: error
    }
}